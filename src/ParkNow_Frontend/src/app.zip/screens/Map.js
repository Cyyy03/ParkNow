import React, {useEffect, useState} from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Button,
  TouchableOpacity,
  TextInput,
  Alert,
  StatusBar,
  ScrollView,
} from 'react-native';
import MapView, {
  Marker,
  PROVIDER_GOOGLE,
  PROVIDER_DEFAULT,
  MapPressEvent,
  LatLng,
} from 'react-native-maps';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
import * as storage from '../utils/storage';
import * as api from '../api/api';
import {Card} from 'react-native-shadow-cards';
import Toast from 'react-native-root-toast';

export default function App(props) {
  const {push} = props.navigation;
  const [positions, setPositions] = useState(null);
  const detail = props.route.params.detail;

  useEffect(() => {
    getLatLng();
  }, []);

  const getLatLng = async ()=>{
    let res = await api.distancef("50 nanyang ave",detail.Address);
    setPositions(res);
    let navigateRoute = await api.navigateRoute(res.source_lat,res.source_lng,res.dest_lat,res.dest_lng);
  }

  const onPressMap = async () => {};

  return (
    <View style={styles.container}>
      <StatusBar
        animated={false} //指定状态栏的变化是否应以动画形式呈现。目前支持这几种样式：backgroundColor, barStyle和hidden
        hidden={false} //是否隐藏状态栏。
        networkActivityIndicatorVisible={false} //仅作用于ios。是否显示正在使用网络。
        showHideTransition={'fade'} //仅作用于ios。显示或隐藏状态栏时所使用的动画效果（’fade’, ‘slide’）。
        backgroundColor="rgba(255,255,255,0)" // {'transparent'} //状态栏的背景色
        translucent={true} //指定状态栏是否透明。设置为true时，应用会在状态栏之下绘制（即所谓“沉浸式”——被状态栏遮住一部分）。常和带有半透明背景色的状态栏搭配使用。
        barStyle={'light-content'} // enum('default', 'light-content', 'dark-content')
      />
      <View style={{flex: 1}}>
        <MapView
          provider={
            Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT
          }
          initialRegion={positions?{
            latitude: positions.source_lat,
            longitude: positions.source_lng,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }:{}}
          zoomControlEnabled={true}
          onPress={onPressMap}
          style={{...StyleSheet.absoluteFillObject}}>
          {/* <Marker
            title="Me"
            description=""
            pinColor="#f0d1a3"
            coordinate={destLoc}
          /> */}
        </MapView>
      </View>

      <View
        style={{
          padding: 20,
          position: 'absolute',
          top: 50,
          left: 0,
          right: 0,
          flexDirection: 'row',
          alignItems:"center"
        }}>
        <View style={{
              backgroundColor: '#fff',
              color: '#000',
              padding: 15,
              flex: 1,
              height:50,
              borderRadius: 10,
            }}>
          <Text
            style={{
              color:"#000",
              fontWeight:"bold"
            }}>
            27 Sawayn Square Carpark A
          </Text>
        </View>
        <Image
          source={require('../images/avatar.png')}
          style={{width: 80, height: 80, borderRadius: 40}}></Image>
      </View>

      <View
        style={{
          backgroundColor: '#000000aa',
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
          padding: 20,
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
        }}>
        <Text style={{fontSize: 17, color: '#fff'}}>Navigating to</Text>
        <Text style={{fontSize: 17, color: '#fff', fontWeight: 'bold'}}>
          27 Sawayn Square Carpark A
        </Text>
        <Text style={{fontSize: 17, color: '#fff', fontWeight: 'bold'}}>
          Distance: 12.2km
        </Text>
        <View style={{flexDirection: 'row', marginTop: 10}}>
          <TouchableOpacity
            style={{
              backgroundColor: '#3879F0',
              flex: 1,
              paddingHorizontal: 15,
              paddingVertical: 10,
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 10,
            }}
            onPress={() => {
              setShowShare(false);
            }}>
            <Text style={{color: '#fff', fontSize: 18, fontWeight: 'bold'}}>
              Cancel
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              backgroundColor: '#3879F0',
              flex: 1,
              paddingHorizontal: 15,
              paddingVertical: 10,
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
            }}
            onPress={() => {
              setShowShare(false);
            }}>
            <Text style={{color: '#fff', fontSize: 18, fontWeight: 'bold'}}>
              Cancel
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#fcf6f6',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    window: 300,
    justifyContent: 'space-between',
  },
  label: {
    color: '#999999',
    fontWeight: 'bold',
    fontSize: 18,
  },
  value: {
    color: '#999999',
    fontWeight: 'bold',
    fontSize: 18,
  },
  bgImage: {
    width: windowWidth,
    height: windowHeight + 50,

    position: 'absolute',
    top: 0,
    left: 0,
    resizeMode: 'stretch',
  },
  input: {
    height: 50,
    backgroundColor: '#fff',
    marginTop: 20,
    borderRadius: 30,
    color: '#000',
    paddingLeft: 10,
    width: 300,
  },
  button: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button2: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codeInput: {
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 30,
    color: '#000',
    paddingLeft: 10,
    width: 190,
  },
  select: {
    flex: 1,
    height: 40,
    borderRadius: 10,
    paddingLeft: 10,
    backgroundColor: '#fff',
  },
});
