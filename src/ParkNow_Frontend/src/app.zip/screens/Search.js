import React, {useEffect, useState} from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Button,
  TouchableOpacity,
  TextInput,
  Alert,
  StatusBar,
  ScrollView,
} from 'react-native';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
import * as storage from '../utils/storage';
import * as api from '../api/api';
import {Card} from 'react-native-shadow-cards';
import Toast from 'react-native-root-toast';

export default function App(props) {
  const {push} = props.navigation;
  
  const [list, setList] = useState([]);
  const [searchkey, setSearchkey] = useState([]);

  useEffect(() => {
    
  }, []);
  // load data
  const search = async () => {
    let res = await api.search('50 Nanyang Avg 639798', 15);
    console.log("search res==",res.nearby_carparks.length);
  };

  return (
    <View style={styles.container}>
      <StatusBar
        animated={false} //指定状态栏的变化是否应以动画形式呈现。目前支持这几种样式：backgroundColor, barStyle和hidden
        hidden={false} //是否隐藏状态栏。
        networkActivityIndicatorVisible={false} //仅作用于ios。是否显示正在使用网络。
        showHideTransition={'fade'} //仅作用于ios。显示或隐藏状态栏时所使用的动画效果（’fade’, ‘slide’）。
        backgroundColor="rgba(255,255,255,0)" // {'transparent'} //状态栏的背景色
        translucent={true} //指定状态栏是否透明。设置为true时，应用会在状态栏之下绘制（即所谓“沉浸式”——被状态栏遮住一部分）。常和带有半透明背景色的状态栏搭配使用。
        barStyle={'dark-content'} // enum('default', 'light-content', 'dark-content')
      />
      <View
        style={{
          alignItems: 'center',
          paddingTop: 60,
          paddingBottom: 30,
          paddingHorizontal: 20,
          flexDirection:"row"
        }}>
        <TouchableOpacity onPress={()=>{
          props.navigation.goBack();
        }}>
          <Image
            source={require('../images/back.png')}
            style={{width: 25, height: 25, borderRadius: 25}}></Image>
        </TouchableOpacity>
        <View
          style={{
            flexDirection: 'row',
            flex:1,
            backgroundColor: '#fff',
            paddingHorizontal: 10,
            paddingVertical: 10,
            borderRadius: 10,
            marginLeft:10,
            alignItems: 'center',
          }}>
          <Image
            source={require('../images/search.png')}
            style={{width: 30, height: 30, borderRadius: 25}}
            resizeMode="contain"></Image>
          <TextInput
            placeholder="Search for location"
            onEndEditing={()=>{
              search();
            }}
            value={searchkey}
            onChangeText={(e)=>{
              setSearchkey(searchkey);
            }}
            style={{
              flex: 1,
              fontSize: 16,
              fontWeight: 'bold',
              color: '#aaa',
              height: 30,
              padding: 0,
              paddingLeft: 10,
            }}></TextInput>
          <Image
            source={require('../images/location.png')}
            style={{width: 20, height: 20, borderRadius: 25}}></Image>
        </View>
      </View>
      <View
        style={{
          backgroundColor: '#fff',
          flex: 1,
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
          paddingHorizontal: 15,
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <Text
            style={{
              color: '#000',
              fontWeight: 'bold',
              padding: 10,
              fontSize: 20,
            }}>
            Results ({list.length})
          </Text>
          <Image
            source={require('../images/filter.png')}
            style={{width: 20, height: 20}}></Image>
        </View>
        <View style={{flex: 1, paddingTop: 20}}>
          <ScrollView>
            {list.map((item,i) => {
              return (
                <TouchableOpacity onPress={()=>{
                  push("Main");
                }} key={i} style={{backgroundColor: '#fff', flexDirection: 'row'}}>
                  <Image
                    source={require('../images/star.png')}
                    style={{width: 20, height: 20}}
                    resizeMode="contain"></Image>
                  <View
                    style={{
                      marginLeft: 10,
                      borderBottomColor: '#eee',
                      paddingBottom: 10,
                      marginBottom: 10,
                      borderBottomWidth: 1,
                      flex: 1,
                    }}>
                    <Text
                      style={{
                        color: '#000',
                        fontSize: 16,
                      }}>
                      {item.name}
                    </Text>
                    <View style={{flexDirection: 'row'}}>
                      <Text
                        style={{
                          color: '#888',
                          fontSize: 14,
                        }}>
                        {item.address},
                      </Text>
                      <Text
                        style={{
                          color: '#888',
                          fontSize: 14,
                          marginLeft: 10,
                        }}>
                        {item.code}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#fcf6f6',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    window: 300,
  },
  label: {
    color: '#fff',
    width: 80,
  },
  bgImage: {
    width: windowWidth,
    height: windowHeight + 50,

    position: 'absolute',
    top: 0,
    left: 0,
    resizeMode: 'stretch',
  },
  input: {
    height: 50,
    backgroundColor: '#fff',
    marginTop: 20,
    borderRadius: 30,
    color: '#000',
    paddingLeft: 10,
    width: 300,
  },
  button: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button2: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codeInput: {
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 30,
    color: '#000',
    paddingLeft: 10,
    width: 190,
  },
  select: {
    flex: 1,
    height: 40,
    borderRadius: 10,
    paddingLeft: 10,
    backgroundColor: '#fff',
  },
});
