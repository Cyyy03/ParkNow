import React, {useEffect, useState} from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Button,
  TouchableOpacity,
  TextInput,
  Alert,
  StatusBar,
} from 'react-native';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
import * as storage from '../utils/storage';
import * as api from '../api/api';

import Toast from 'react-native-root-toast';

export default function App(props) {
  const {push} = props.navigation;

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const login = async () => {
   
    if (!username) {
      Toast.show('Please Enter your username.');
      return;
    }
    if (!password) {
      Toast.show('Please Enter your password.');
      return;
    }

  
    let res = await api.login({
      username: username,
      password: password,
    });
    console.log('res========', res);
    if (res.success) {
      await storage.saveUser(res.data);
      push("Main");
    } else {
      Toast.show(res.mess);
     
    }
  };

  useEffect(() => {
  
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar
        animated={false} //指定状态栏的变化是否应以动画形式呈现。目前支持这几种样式：backgroundColor, barStyle和hidden
        hidden={false} //是否隐藏状态栏。
        networkActivityIndicatorVisible={false} //仅作用于ios。是否显示正在使用网络。
        showHideTransition={'fade'} //仅作用于ios。显示或隐藏状态栏时所使用的动画效果（’fade’, ‘slide’）。
        backgroundColor="rgba(255,255,255,255)" // {'transparent'} //状态栏的背景色
        translucent={false} //指定状态栏是否透明。设置为true时，应用会在状态栏之下绘制（即所谓“沉浸式”——被状态栏遮住一部分）。常和带有半透明背景色的状态栏搭配使用。
        barStyle={'dark-content'} // enum('default', 'light-content', 'dark-content')
      />
      <View style={{display: 'flex', alignItems: 'flex-start'}}>
        <Text
          style={{
            color: '#000',
            fontWeight: 'bold',
            fontSize: 20,
            marginTop: 20,
          }}>
          Welcome back!
        </Text>
        <View style={{flexDirection: 'row', marginBottom: 20}}>
          <Text style={{color: '#666'}}>Sign in to your account</Text>
        </View>

        <Text style={styles.label}>Username</Text>
        <TextInput
          style={styles.input}
          value={username}
          onChangeText={text => {
            setUsername(text);
          }}
          placeholder="Enter your username"
          placeholderTextColor="#D1CDD0"></TextInput>

        <Text style={styles.label}>Password</Text>
        <TextInput
          style={styles.input}
          secureTextEntry={true}
          value={password}
          onChangeText={text => {
            setPassword(text);
          }}
          placeholder="Enter your password"
          placeholderTextColor="#D1CDD0"></TextInput>
        <TouchableOpacity
          style={{
            color: '#41D5FB',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            width:windowWidth-40,
            marginTop:20
          }}>
          <Text style={{
            color: '#41D5FB',fontWeight:"bold"}}>Forgot your password?</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            backgroundColor: '#7687ff',
            marginTop: 40,
            width: windowWidth - 40,
            flexDirection: 'row',
            height: 45,
            borderRadius: 5,
            justifyContent: 'center',
            alignItems: 'center',
          }}
          onPress={() => {
            login();
          }}>
          <Text style={{fontSize: 18, color: '#fff'}}>Sign in</Text>
        </TouchableOpacity>
        <View style={{marginTop: 20, flexDirection: 'row'}}>
          <Text style={{color: '#666'}}>Don't have an account?</Text>
          <TouchableOpacity style={{color: '#41D5FB'}} onPress={()=>{
            props.navigation.push("Signup");
          }}>
            <Text style={{color: '#41D5FB'}}>Sign up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#fff',
    paddingLeft: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    window: 300,
  },
  label: {
    color: '#000',
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 10,
  },
  bgImage: {
    width: windowWidth,
    height: windowHeight + 50,

    position: 'absolute',
    top: 0,
    left: 0,
    resizeMode: 'stretch',
  },
  input: {
    height: 50,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    color: '#000',
    paddingLeft: 10,
    width:windowWidth-40
  },
  button: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button2: {
    marginTop: 20,
    width: 150,
    backgroundColor: '#fff',
    textAlign: 'center',
    borderRadius: 5,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codeInput: {
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 30,
    color: '#000',
    paddingLeft: 10,
    width: 190,
  },
  select: {
    flex: 1,
    height: 40,
    borderRadius: 10,
    paddingLeft: 10,
    backgroundColor: '#fff',
  },
});
