import React, {useEffect, useState} from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Button,
  TouchableOpacity,
  TextInput,
  Alert,
  StatusBar,
} from 'react-native';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
import * as storage from '../utils/storage';
import * as api from '../api/api';

import Toast from 'react-native-root-toast';
import Swiper from 'react-native-swiper';

export default function App(props) {
  useEffect(() => {}, []);

  const signup = () => {
    props.navigation.push('Signup');
  };

  const login = () => {
    props.navigation.push('Login');
  };

  return (
    <View
      style={{
        backgroundColor: '#fff',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <StatusBar
        animated={false} //指定状态栏的变化是否应以动画形式呈现。目前支持这几种样式：backgroundColor, barStyle和hidden
        hidden={false} //是否隐藏状态栏。
        networkActivityIndicatorVisible={false} //仅作用于ios。是否显示正在使用网络。
        showHideTransition={'fade'} //仅作用于ios。显示或隐藏状态栏时所使用的动画效果（’fade’, ‘slide’）。
        barStyle={'light-content'} // enum('default', 'light-content', 'dark-content')
      />
      <Image
        source={require('../images/loginhome.png')}
        style={{position: 'absolute', width: windowWidth, height: windowHeight+50}}
        resizeMode="cover"></Image>
      <View style={{flex:1,paddingTop:80}}>
        <Image
          source={require('../images/logo.png')}
          style={{width: 100, height: 150}}
          resizeMode="cover"></Image>
        <Text style={{color: '#000', fontSize: 20, fontWeight: 'bold'}}>
          ParkNow
        </Text>
      </View>
      <View
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginHorizontal: 40,
          paddingBottom: 40,
        }}>
        <TouchableOpacity
          onPress={() => {
            signup();
          }}
          style={{
            backgroundColor: '#3879F0',
            paddingHorizontal: 10,
            paddingVertical: 5,
            borderRadius: 5,
          }}>
          <Text style={{color: '#fff'}}>Sign up</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            login();
          }}
          style={{
            borderColor: '#fff',
            borderWidth:1,
            paddingHorizontal: 10,
            paddingVertical: 5,
            borderRadius: 5,
            marginLeft:20
          }}>
          <Text style={{color: '#fff'}}>Log in</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
  },
  slide1: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9DD6EB',
  },
  slide2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#97CAE5',
  },
  slide3: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#92BBD9',
  },
  text: {
    color: '#000',
    fontSize: 30,
    fontWeight: 'bold',
  },
});
